<html>
<head>
    <title>Contact Us</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<header>
    Get in Touch
</header>
<div class="container">
    <p>We’d love to hear from you! Reach out for any questions or reservations.</p>
    <ul>
        <li>Email: contact@experience.com</li>
        <li>Phone: +123 456 7890</li>
        <li>Address: 123 Dining Street, Food City</li>
    </ul>
    <a href="index.php">Back to Home</a>
</div>
</body>
</html>
