<html>
<head>
    <title>Reserve Your Dining Experience</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<header>
    <h1>Reserve Your Table at Experience Restaurant</h1>
</header>
<div class="container">
    <h2>Table Reservation</h2>
    <p>Please fill in the details below to book your dining experience. We’ll confirm your reservation shortly.</p>
    <form method="POST" action="php/add_reservation.php">
        <fieldset>
            <legend>Customer Information</legend>
            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" placeholder="Your Name" required><br>

            <label for="email">Email Address:</label>
            <input type="email" id="email" name="email" placeholder="Your Email" required>
        </fieldset>

        <fieldset>
            <legend>Reservation Details</legend>
            <label for="date_time">Date & Time:</label>
            <input type="datetime-local" id="date_time" name="date_time" required><br>

            <label for="occasion">Occasion:</label>
            <select id="occasion" name="occasion" required>
                <option value="" disabled selected>Select Occasion</option>
                <option value="Birthday">Birthday</option>
                <option value="Anniversary">Anniversary</option>
                <option value="Business Meeting">Business Meeting</option>
                <option value="Casual Dining">Casual Dining</option>
            </select><br>

            <label for="guests">Number of Guests:</label>
            <input type="number" id="guests" name="guests" min="1" max="20" placeholder="Number of Guests" required><br>
        </fieldset>

        <fieldset>
            <legend>Special Requests</legend>
            <textarea id="notes" name="notes" placeholder="Any special requests? (e.g., allergies, seating preferences)" rows="4"></textarea>
        </fieldset>

        <button type="submit" class="btn-primary">Book Table</button>
    </form>
    <a href="index.php">Back to Home</a>
</div>
</body>
</html>
