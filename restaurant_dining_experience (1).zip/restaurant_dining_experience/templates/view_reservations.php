<html>
<head>
    <title>Manage Reservations</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<header>
    <h1>Manage Your Reservations</h1>
</header>
<div class="container">
    <table>
        <thead>
            <tr>
                <th>Reservation ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Date & Time</th>
                <th>Occasion</th>
                <th>Guests</th>
                <th>Special Requests</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            require_once 'php/db.php';

            $sql = "SELECT Reservations.id, Customers.name, Customers.email, Reservations.date_time, Reservations.occasion, Reservations.guests, Reservations.notes 
                    FROM Reservations 
                    JOIN Customers ON Reservations.customer_id = Customers.id";
            $result = $conn->query($sql);

            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['email']}</td>
                        <td>{$row['date_time']}</td>
                        <td>{$row['occasion']}</td>
                        <td>{$row['guests']}</td>
                        <td>{$row['notes']}</td>
                        <td>
                            <a href='index.php?action=modifyReservation&id={$row['id']}' class='btn-secondary'>Modify</a>
                            <a href='php/delete_reservation.php?id={$row['id']}' class='btn-danger' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='8'>No reservations found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
    <a href="index.php">Back to Home</a>
</div>
</body>
</html>
