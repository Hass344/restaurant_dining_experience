<html>
<head>
    <title>Welcome to Experience Restaurant</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<header>
    Welcome to Experience Restaurant
</header>
<div class="container">
    <h2>Discover Fine Dining</h2>
    <p>Book a table, manage your reservations, and enjoy an unparalleled dining experience.</p>
    <a href="index.php?action=addReservation">Reserve Now</a> |
    <a href="index.php?action=viewReservations">Manage Reservations</a> |
    <a href="index.php?action=about">About Us</a> |
    <a href="index.php?action=contact">Contact</a>
</div>
</body>
</html>
