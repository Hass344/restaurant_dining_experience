<html>
<head>
    <title>About Us</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<header>
    About Experience Restaurant
</header>
<div class="container">
    <p>Welcome to Experience Restaurant, where we bring you the finest dining experience. Our team is committed to making your visit memorable.</p>
    <a href="index.php">Back to Home</a>
</div>
</body>
</html>
