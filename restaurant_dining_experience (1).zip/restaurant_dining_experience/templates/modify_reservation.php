<html>
<head>
    <title>Modify Reservation</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<header>
    Update Reservation Details
</header>
<div class="container">
    <?php
    require_once 'php/db.php';
    $id = $_GET['id'] ?? null;

    if ($id) {
        $sql = "SELECT Reservations.*, Customers.name, Customers.email 
                FROM Reservations 
                JOIN Customers ON Reservations.customer_id = Customers.id 
                WHERE Reservations.id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $reservation = $result->fetch_assoc();
    }

    if (!$reservation) {
        echo "<p>Reservation not found!</p>";
        echo "<a href='index.php?action=viewReservations'>Back to Reservations</a>";
        exit;
    }
    ?>
    <form method="POST" action="php/modify_reservation.php">
        <input type="hidden" name="id" value="<?= htmlspecialchars($reservation['id']) ?>">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?= htmlspecialchars($reservation['name']) ?>" disabled><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?= htmlspecialchars($reservation['email']) ?>" disabled><br>

        <label for="date_time">Date & Time:</label>
        <input type="datetime-local" id="date_time" name="date_time" value="<?= htmlspecialchars($reservation['date_time']) ?>" required><br>

        <label for="occasion">Occasion:</label>
        <select id="occasion" name="occasion" required>
            <option value="Birthday" <?= $reservation['occasion'] == 'Birthday' ? 'selected' : '' ?>>Birthday</option>
            <option value="Anniversary" <?= $reservation['occasion'] == 'Anniversary' ? 'selected' : '' ?>>Anniversary</option>
            <option value="Business" <?= $reservation['occasion'] == 'Business' ? 'selected' : '' ?>>Business</option>
        </select><br>

        <label for="guests">Number of Guests:</label>
        <input type="number" id="guests" name="guests" value="<?= htmlspecialchars($reservation['guests']) ?>" required><br>

        <label for="notes">Special Requests:</label>
        <textarea id="notes" name="notes"><?= htmlspecialchars($reservation['notes']) ?></textarea><br>

        <button type="submit">Update Reservation</button>
    </form>
    <a href="index.php?action=viewReservations">Back to Reservations</a>
</div>
</body>
</html>
