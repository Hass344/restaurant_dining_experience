<?php
require_once 'php/db.php';
$action = $_GET['action'] ?? 'home';

switch ($action) {
    case 'addReservation':
        include 'templates/add_reservation.php';
        break;
    case 'viewReservations':
        include 'templates/view_reservations.php';
        break;
    case 'modifyReservation':
        include 'templates/modify_reservation.php';
        break;
    case 'about':
        include 'templates/about.php';
        break;
    case 'contact':
        include 'templates/contact.php';
        break;
    default:
        include 'templates/home.php';
}
?>
