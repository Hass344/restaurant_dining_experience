document.addEventListener('DOMContentLoaded', () => {
    console.log("The Gourmet Hub System Loaded Successfully.");
});
