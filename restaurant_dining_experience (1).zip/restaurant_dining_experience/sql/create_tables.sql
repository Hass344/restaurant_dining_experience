CREATE DATABASE restaurant_dining_experience;

USE restaurant_dining_experience;

-- Customers Table
CREATE TABLE Customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(200) NOT NULL UNIQUE
);

-- Reservations Table
CREATE TABLE Reservations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    date_time DATETIME NOT NULL,
    occasion VARCHAR(50),
    guests INT NOT NULL,
    notes TEXT,
    FOREIGN KEY (customer_id) REFERENCES Customers(id) ON DELETE CASCADE
);

