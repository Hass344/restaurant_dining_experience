<?php
require_once 'db.php';

$id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM Reservations WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: ../index.php?action=viewReservations");
exit;
?>
