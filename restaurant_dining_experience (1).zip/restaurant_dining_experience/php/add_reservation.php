<?php
require_once 'db.php';

$name = $_POST['name'];
$email = $_POST['email'];
$date_time = $_POST['date_time'];
$occasion = $_POST['occasion'];
$guests = $_POST['guests'];
$notes = $_POST['notes'];

// Insert customer
$stmt = $conn->prepare("INSERT INTO Customers (name, email) VALUES (?, ?) ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)");
$stmt->bind_param("ss", $name, $email);
$stmt->execute();
$customer_id = $stmt->insert_id;

// Insert reservation
$stmt = $conn->prepare("INSERT INTO Reservations (customer_id, date_time, occasion, guests, notes) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("issis", $customer_id, $date_time, $occasion, $guests, $notes);
$stmt->execute();

header("Location: ../index.php?action=viewReservations");
exit;
?>
