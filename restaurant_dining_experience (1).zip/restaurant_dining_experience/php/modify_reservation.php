<?php
require_once 'db.php';

$id = $_POST['id'];
$date_time = $_POST['date_time'];
$occasion = $_POST['occasion'];
$guests = $_POST['guests'];
$notes = $_POST['notes'];

$stmt = $conn->prepare("UPDATE Reservations SET date_time = ?, occasion = ?, guests = ?, notes = ? WHERE id = ?");
$stmt->bind_param("ssisi", $date_time, $occasion, $guests, $notes, $id);
$stmt->execute();

header("Location: ../index.php?action=viewReservations");
exit;
?>
